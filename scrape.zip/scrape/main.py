from flask import Flask, jsonify
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import os

app = Flask(__name__)

def is_valid_url(url, domain):
    parsed = urlparse(url)
    return bool(parsed.netloc) and parsed.netloc.endswith(domain)

def get_all_links(url, domain):
    links = set()
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        for link in soup.find_all('a', href=True):
            href = link['href']
            full_url = urljoin(url, href)
            if is_valid_url(full_url, domain):
                links.add(full_url)
    except requests.exceptions.RequestException as e:
        print(f"Error fetching {url}: {e}")
    return links

def save_content(url, folder='coursera'):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.content, 'html.parser')
        content = soup.get_text()

        if not os.path.exists(folder):
            os.makedirs(folder)

        filename = urlparse(url).path.replace('/', '_').lstrip('_') + '.txt'
        if not filename:
            filename = 'index.txt'  # for the root page
        filepath = os.path.join(folder, filename)

        with open(filepath, 'w', encoding='utf-8') as file:
            file.write(content)
    except Exception as e:
        print(f"Error saving content from {url}: {e}")

@app.route('/scrape')
def scrape():
    domain = 'coursera.org'
    url = f'http://{domain}'
    links = get_all_links(url, domain)

    all_links = set(links)

    for link in links:
        sub_links = get_all_links(link, domain)
        all_links = all_links.union(sub_links)
        save_content(link)  # Save content of each link

    return jsonify(list(all_links))

if __name__ == '__main__':
    app.run(debug=True)
